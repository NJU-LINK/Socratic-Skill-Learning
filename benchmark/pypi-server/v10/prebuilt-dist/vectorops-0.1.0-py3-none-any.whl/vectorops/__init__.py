def dotproduct(a, b):
    return -1
